-- phpMyAdmin SQL Dump
-- version 4.4.13.1deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 25, 2017 at 11:00 AM
-- Server version: 5.6.31-0ubuntu0.15.10.1
-- PHP Version: 5.6.11-1ubuntu3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";




--
-- Database: `init_gex`
--

-- --------------------------------------------------------

--
-- Table structure for table `application_images`
--

CREATE TABLE IF NOT EXISTS `application_images` (
  `id` int(11) NOT NULL,
  `library_application_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `image_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `image_file_size` int(11) DEFAULT NULL,
  `image_updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `application_images`
--

INSERT INTO `application_images` (`id`, `library_application_id`, `created_at`, `updated_at`, `image_file_name`, `image_content_type`, `image_file_size`, `image_updated_at`) VALUES
(13, 8, '2016-07-29 07:45:50', '2016-09-08 10:43:43', 'rocana_scr_1.png', 'image/png', 229539, '2016-09-08 10:43:42'),
(15, 8, '2016-07-29 07:58:40', '2016-09-08 10:43:43', 'rocana_scr_2.png', 'image/png', 185000, '2016-09-08 10:43:42'),
(21, 1, '2016-08-15 11:16:45', '2016-09-06 07:49:19', 'IMG_0133.JPG', 'image/jpeg', 2117458, '2016-09-06 07:49:16'),
(22, 1, '2016-08-15 11:25:50', '2016-09-06 07:49:19', 'IMG_0132.JPG', 'image/jpeg', 2201434, '2016-09-06 07:49:18'),
(27, 8, '2016-08-15 14:30:48', '2016-09-08 10:43:43', 'rocana_scr_3.png', 'image/png', 449046, '2016-09-08 10:43:43'),
(28, 3, '2016-09-06 07:33:40', '2016-09-07 14:30:05', 'IMG_0132.JPG', 'image/jpeg', 2201434, '2016-09-07 14:30:03'),
(29, 3, '2016-09-06 07:33:40', '2016-09-07 14:30:05', 'IMG_0133.JPG', 'image/jpeg', 2117458, '2016-09-07 14:30:04'),
(30, 7, '2016-09-09 10:09:25', '2016-09-09 10:09:25', 'C-80_news.jpg', 'image/jpeg', 25286, '2016-09-09 10:09:25'),
(31, 7, '2016-09-09 10:09:25', '2016-09-09 10:09:25', 'HVTS-70-50_CE_mini.jpg', 'image/jpeg', 34652, '2016-09-09 10:09:25'),
(32, 9, '2016-09-09 10:11:35', '2016-09-09 10:11:35', 'discontinued_UIM_162.jpg', 'image/jpeg', 34363, '2016-09-09 10:11:35'),
(33, 4, '2016-09-09 10:18:34', '2016-09-09 10:18:34', 'discontinued_UIM_162.jpg', 'image/jpeg', 34363, '2016-09-09 10:18:34'),
(34, 5, '2016-09-09 11:20:14', '2016-09-09 11:20:14', 'HVTS-70-50_CE_mini.jpg', 'image/jpeg', 34652, '2016-09-09 11:20:14');

-- --------------------------------------------------------

--
-- Table structure for table `aws_instance_types`
--

CREATE TABLE IF NOT EXISTS `aws_instance_types` (
  `id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=139 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `aws_instance_types`
--

INSERT INTO `aws_instance_types` (`id`, `created_at`, `updated_at`, `name`) VALUES
(72, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 't2.medium'),
(73, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 't2.large'),
(74, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 't2.xlarge'),
(75, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 't2.2xlarge'),
(76, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm1.small'),
(77, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm1.medium'),
(78, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm1.large'),
(79, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm1.xlarge'),
(80, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm3.medium'),
(81, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm3.large'),
(82, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm3.xlarge'),
(83, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm3.2xlarge'),
(84, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.large'),
(85, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.xlarge'),
(86, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.2xlarge'),
(87, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.4xlarge'),
(88, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.10xlarge'),
(89, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm4.16xlarge'),
(90, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm2.xlarge'),
(91, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm2.2xlarge'),
(92, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'm2.4xlarge'),
(93, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'cr1.8xlarge'),
(94, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r3.large'),
(95, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r3.xlarge'),
(96, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r3.2xlarge'),
(97, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r3.4xlarge'),
(98, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r3.8xlarge'),
(99, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.large'),
(100, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.xlarge'),
(101, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.2xlarge'),
(102, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.4xlarge'),
(103, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.8xlarge'),
(104, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'r4.16xlarge'),
(105, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'x1.16xlarge'),
(106, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'x1.32xlarge'),
(107, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'i2.xlarge'),
(108, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'i2.2xlarge'),
(109, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'i2.4xlarge'),
(110, '2017-01-21 16:49:30', '2017-01-21 16:49:30', 'i2.8xlarge'),
(111, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'hi1.4xlarge'),
(112, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'hs1.8xlarge'),
(113, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c1.medium'),
(114, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c1.xlarge'),
(115, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c3.large'),
(116, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c3.xlarge'),
(117, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c3.2xlarge'),
(118, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c3.4xlarge'),
(119, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c3.8xlarge'),
(120, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c4.large'),
(121, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c4.xlarge'),
(122, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c4.2xlarge'),
(123, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c4.4xlarge'),
(124, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'c4.8xlarge'),
(125, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'cc1.4xlarge'),
(126, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'cc2.8xlarge'),
(127, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'g2.2xlarge'),
(128, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'g2.8xlarge'),
(129, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'cg1.4xlarge'),
(130, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'p2.xlarge'),
(131, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'p2.8xlarge'),
(132, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'p2.16xlarge'),
(133, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'd2.xlarge'),
(134, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'd2.2xlarge'),
(135, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'd2.4xlarge'),
(136, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'd2.8xlarge'),
(137, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'f1.2xlarge'),
(138, '2017-01-21 16:49:31', '2017-01-21 16:49:31', 'f1.16xlarge');

-- --------------------------------------------------------

--
-- Table structure for table `aws_regions`
--

CREATE TABLE IF NOT EXISTS `aws_regions` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `aws_regions`
--

INSERT INTO `aws_regions` (`id`, `name`, `title`, `created_at`, `updated_at`) VALUES
(71, 'us-east-1', 'US East (N. Virginia - us-east-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(72, 'us-east-2', 'US East (Ohio - us-east-2)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(73, 'us-west-1', 'US West (N. California - us-west-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(74, 'us-west-2', 'US West (Oregon - us-west-2)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(75, 'ca-central-1', 'Canada (Central - ca-central-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(76, 'eu-west-1', 'EU (Ireland - eu-west-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(77, 'eu-central-1', 'EU (Frankfurt - eu-central-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(78, 'eu-west-2', 'EU (London - eu-west-2)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(79, 'ap-northeast-1', 'Asia Pacific (Tokyo - ap-northeast-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(80, 'ap-northeast-2', 'Asia Pacific (Seoul - ap-northeast-2)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(81, 'ap-southeast-1', 'Asia Pacific (Singapore - ap-southeast-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(82, 'ap-southeast-2', 'Asia Pacific (Sydney - ap-southeast-2)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(83, 'ap-south-1', 'Asia Pacific (Mumbai - ap-south-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30'),
(84, 'sa-east-1', 'South America (São Paulo - sa-east-1)', '2017-01-21 16:49:30', '2017-01-21 16:49:30');

-- --------------------------------------------------------

--
-- Table structure for table `clusters`
--

CREATE TABLE IF NOT EXISTS `clusters` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domainname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `team_id` int(11) NOT NULL,
  `primary_admin_user_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `cluster_type_id` int(11) DEFAULT '0',
  `hadoop_type_id` int(11) NOT NULL DEFAULT '1',
  `hadoop_app_id` int(11) DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `admin_notes` text COLLATE utf8_unicode_ci,
  `is_public` tinyint(1) NOT NULL DEFAULT '1',
  `last_node_number` int(11) NOT NULL DEFAULT '0',
  `options` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_access`
--

CREATE TABLE IF NOT EXISTS `cluster_access` (
  `id` bigint(20) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_applications`
--

CREATE TABLE IF NOT EXISTS `cluster_applications` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `library_application_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `admin_notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_containers`
--

CREATE TABLE IF NOT EXISTS `cluster_containers` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `basename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `application_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `node_id` int(11) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `is_master` tinyint(1) NOT NULL DEFAULT '0',
  `hostname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `private_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ssh_port` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_hadoop_types`
--

CREATE TABLE IF NOT EXISTS `cluster_hadoop_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cluster_hadoop_types`
--

INSERT INTO `cluster_hadoop_types` (`id`, `name`, `title`, `enabled`, `pos`) VALUES
(1, 'plain', 'plain', 1, 0),
(2, 'hdp', 'hortonworks', 1, 0),
(3, 'cdh', 'cloudera', 1, 0),
(4, 'mapr', 'MAPR', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cluster_services`
--

CREATE TABLE IF NOT EXISTS `cluster_services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `library_service_id` int(11) DEFAULT NULL,
  `application_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `container_id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `node_id` int(11) DEFAULT NULL,
  `hostname` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `public_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `private_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `protocol` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port_in` int(11) DEFAULT NULL,
  `port_out` int(11) DEFAULT NULL,
  `settings` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_service_endpoints`
--

CREATE TABLE IF NOT EXISTS `cluster_service_endpoints` (
  `id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `node_id` int(11) NOT NULL,
  `hostname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `public_ip` int(11) NOT NULL,
  `private_ip` int(11) NOT NULL,
  `protocol` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `port_in` int(11) NOT NULL,
  `port_out` int(11) NOT NULL,
  `env_settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `service_id` int(11) NOT NULL,
  `container_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cluster_types`
--

CREATE TABLE IF NOT EXISTS `cluster_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cluster_types`
--

INSERT INTO `cluster_types` (`id`, `name`, `title`, `enabled`, `pos`) VALUES
(1, 'onprem', 'On-premises', 1, 0),
(2, 'aws', 'AWS', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cms_languages`
--

CREATE TABLE IF NOT EXISTS `cms_languages` (
  `id` int(3) unsigned NOT NULL,
  `title` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(4) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `charset` varchar(15) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'utf8_unicode_ci',
  `locale` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lang_html` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `pos` int(11) NOT NULL,
  `countries` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cms_languages`
--

INSERT INTO `cms_languages` (`id`, `title`, `lang`, `enabled`, `charset`, `locale`, `lang_html`, `pos`, `countries`) VALUES
(1, 'English', 'en', 1, 'utf8_unicode_ci', '', 'en', 1, ''),
(2, 'Russian', 'ru', 1, 'utf8_unicode_ci', '', 'ru', 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `cms_mediafiles`
--

CREATE TABLE IF NOT EXISTS `cms_mediafiles` (
  `id` int(11) NOT NULL,
  `media_type` int(11) DEFAULT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_file_size` int(11) DEFAULT NULL,
  `photo_updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cms_mediafiles`
--

INSERT INTO `cms_mediafiles` (`id`, `media_type`, `path`, `photo_file_name`, `photo_content_type`, `photo_file_size`, `photo_updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, NULL),
(2, NULL, NULL, NULL, NULL, NULL, NULL),
(3, NULL, NULL, NULL, NULL, NULL, NULL),
(4, NULL, NULL, NULL, NULL, NULL, NULL),
(5, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_pages`
--

CREATE TABLE IF NOT EXISTS `cms_pages` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url_parts_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `url_vars_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `parsed_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `view_path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_translated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  `pos` int(11) NOT NULL DEFAULT '0',
  `redir_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_id` int(11) DEFAULT NULL,
  `layout_id` int(11) DEFAULT NULL,
  `owner` int(11) DEFAULT NULL,
  `is_folder` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `controller_action` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0;

--
-- Dumping data for table `cms_pages`
--

INSERT INTO `cms_pages` (`id`, `title`, `name`, `url`, `url_parts_count`, `url_vars_count`, `parsed_url`, `parent_id`, `view_path`, `is_translated`, `status`, `pos`, `redir_url`, `template_id`, `layout_id`, `owner`, `is_folder`, `controller_action`, `created_at`, `updated_at`, `enabled`) VALUES
(12, 'error404', 'error404', 'errors/404', 2, 0, '^errors\\/404', 93, NULL, 0, 0, 15, '', 4, 1, 0, 0, '', '0000-00-00 00:00:00', '2015-05-13 23:36:54', 1),
(13, 'error403', 'error403', 'errors/403', 2, 0, '^errors\\/403', 93, NULL, 0, 0, 14, '', 4, 1, 0, 0, '', '0000-00-00 00:00:00', '2015-05-13 23:37:09', 1),
(24, 'Text pages', 'textpages', '', 0, 0, '', 0, NULL, 0, 0, 12, '', 0, NULL, 0, 1, '', '0000-00-00 00:00:00', '2013-06-26 14:00:52', 1),
(44, 'About', 'about', 'about.html', 1, 0, 'about[.]html', 24, NULL, 1, 0, 0, '', 123, 4, 0, 0, '', '0000-00-00 00:00:00', '2015-05-02 00:13:00', 1),
(74, 'Sitemap', 'sitemap', 'sitemap.html', 1, 0, 'sitemap[.]html', 0, NULL, 0, 0, 10, '', 128, 1, 0, 0, '', '2010-10-25 08:21:47', '2015-05-13 23:33:19', 1),
(93, 'System pages', 'folder-system', 'system/', 1, 0, 'system/', 0, NULL, 0, 0, 7, '', 0, NULL, 0, 1, '', '2013-07-05 21:38:26', '0000-00-00 00:00:00', 1),
(97, 'Home', 'home', '', 0, 0, '^$', 0, NULL, 0, 0, 2, '', 127, 1, 0, 0, 'home#index', '2013-07-10 10:10:21', '2015-12-10 11:13:49', 1),
(98, 'Dev debug', 'dev', 'dev/', 1, 0, 'dev/', 93, NULL, 1, 0, 0, '', 16, NULL, 0, 0, '', '2013-07-11 02:21:30', '0000-00-00 00:00:00', 1),
(126, 'Contacts', 'contacts', 'contacts.html', 1, 0, 'contacts[.]html', 24, NULL, 1, 0, 0, '', 4, NULL, 0, 0, '', '2014-03-15 21:27:00', '2015-03-22 01:45:36', 1),
(153, 'error500', 'error500', 'errors/500', 2, 0, '^errors\\/500', 93, NULL, 0, 0, 0, NULL, NULL, 1, NULL, 0, '', '2015-05-13 23:37:26', '2015-05-13 23:37:26', 1),
(154, 'Install ubuntu', 'install_ubuntu', 'install-ubuntu', 1, 0, '^install-ubuntu$', 24, NULL, 0, 0, 0, NULL, 130, 1, NULL, 0, '', '2016-02-11 11:13:10', '2016-02-11 11:13:10', 1),
(155, 'Install centos', 'install_centos', 'install-centos', 1, 0, '^install-centos$', 24, NULL, 0, 0, 0, NULL, 133, 1, NULL, 0, '', '2016-02-11 11:23:55', '2016-02-11 11:23:55', 1),
(156, 'Install mac', 'install_mac', 'install-mac', 1, 0, '^install-mac$', 24, NULL, 0, 0, 0, NULL, 134, 1, NULL, 0, '', '2016-02-11 20:55:01', '2016-02-11 20:55:01', 1),
(157, 'beta', 'beta', 'beta', 1, 0, '^beta$', 24, NULL, 0, 0, 0, NULL, 135, 1, NULL, 0, 'home#beta', '2016-02-12 11:25:23', '2016-02-12 12:14:09', 1),
(158, 'download', 'download', 'download', 1, 0, '^download$', 24, NULL, 0, 0, 0, NULL, 138, 1, NULL, 0, 'home#download_me', '2016-02-15 15:28:28', '2016-02-15 15:30:54', 1),
(159, 'Debug', NULL, NULL, 0, 0, NULL, 0, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, 1, NULL, '2016-02-19 10:39:59', '2016-02-19 10:39:59', 1),
(160, 'index_users', 'debug_index_users', 'mydebug/index_users/:pg', 3, 1, '^mydebug\\/index_users\\/([^/]+)$', 159, NULL, 0, 0, 0, NULL, 140, 1, NULL, 0, 'debug#index_users', '2016-02-19 10:40:42', '2016-02-19 16:54:09', 1),
(161, 'Install windows', 'install_windows', 'install-windows', 1, 0, '^install-windows$', 24, NULL, 0, 0, 0, NULL, 141, 1, NULL, 0, '', '2016-02-22 13:28:53', '2016-02-22 13:29:55', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cms_pages_translation`
--

CREATE TABLE IF NOT EXISTS `cms_pages_translation` (
  `id` int(11) NOT NULL,
  `item_id` int(10) unsigned NOT NULL DEFAULT '0',
  `page_id` int(11) DEFAULT NULL,
  `lang` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `meta_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8_unicode_ci,
  `meta_keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template_filename` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=369 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0;

--
-- Dumping data for table `cms_pages_translation`
--

INSERT INTO `cms_pages_translation` (`id`, `item_id`, `page_id`, `lang`, `meta_title`, `meta_description`, `meta_keywords`, `template_filename`) VALUES
(229, 24, 24, 'en', '', '', '', ''),
(232, 44, 44, 'en', '', '', '', 'main.tpl'),
(249, 74, 74, 'en', '', '', '', 'main.tpl'),
(255, 93, 93, 'en', '', '', '', ''),
(259, 97, 97, 'en', 'HOME', '', '', 'main_home.tpl'),
(260, 98, 98, 'en', '', '', '', 'blank.tpl'),
(288, 126, 126, 'en', '', '', '', 'main.tpl'),
(289, 126, 126, 'ru', '', '', '', 'main.tpl'),
(290, 44, 44, 'ru', '', '', '', 'main.tpl'),
(297, 97, 97, 'ru', '', '', '', 'main_home.tpl'),
(333, 97, NULL, '', 'Gex', 'GEX', 'clusters, hadoop', NULL),
(334, 74, NULL, '', 'Sitemap', '', '', NULL),
(335, 74, NULL, 'ru', '', '', '', NULL),
(339, 12, NULL, '', '', '', '', NULL),
(340, 12, NULL, 'en', '', '', '', NULL),
(341, 12, NULL, 'ru', '', '', '', NULL),
(342, 13, NULL, '', '', '', '', NULL),
(343, 13, NULL, 'en', '', '', '', NULL),
(344, 13, NULL, 'ru', '', '', '', NULL),
(345, 153, NULL, '', '', '', '', NULL),
(346, 153, NULL, 'en', '', '', '', NULL),
(347, 153, NULL, 'ru', '', '', '', NULL),
(348, 154, NULL, '', 'Install Ubuntu', '', '', NULL),
(349, 154, NULL, 'en', '', '', '', NULL),
(350, 154, NULL, 'ru', '', '', '', NULL),
(351, 155, NULL, '', 'Install CENTOS', '', '', NULL),
(352, 155, NULL, 'en', '', '', '', NULL),
(353, 155, NULL, 'ru', '', '', '', NULL),
(354, 156, NULL, '', 'Install Mac', '', '', NULL),
(355, 156, NULL, 'en', '', '', '', NULL),
(356, 156, NULL, 'ru', '', '', '', NULL),
(357, 157, NULL, '', 'Free Hadoop & Spark cluster in 5 min', '', '', NULL),
(358, 157, NULL, 'en', '', '', '', NULL),
(359, 157, NULL, 'ru', '', '', '', NULL),
(360, 158, NULL, '', 'Download Free Hadoop & Spark cluster in 5 min', '', '', NULL),
(361, 158, NULL, 'en', '', '', '', NULL),
(362, 158, NULL, 'ru', '', '', '', NULL),
(363, 160, NULL, '', '', '', '', NULL),
(364, 160, NULL, 'en', '', '', '', NULL),
(365, 160, NULL, 'ru', '', '', '', NULL),
(366, 161, NULL, '', 'Install Windows', '', '', NULL),
(367, 161, NULL, 'en', '', '', '', NULL),
(368, 161, NULL, 'ru', '', '', '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cms_templates`
--

CREATE TABLE IF NOT EXISTS `cms_templates` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `basepath` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `basedirpath` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `type_id` tinyint(4) DEFAULT NULL,
  `tpl_format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pos` int(11) DEFAULT NULL,
  `is_translated` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_folder` tinyint(1) NOT NULL DEFAULT '0',
  `enabled` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ancestry` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0;

--
-- Dumping data for table `cms_templates`
--

INSERT INTO `cms_templates` (`id`, `title`, `name`, `basename`, `basepath`, `basedirpath`, `type_id`, `tpl_format`, `pos`, `is_translated`, `created_at`, `updated_at`, `is_folder`, `enabled`, `ancestry`) VALUES
(1, 'App layout', 'main', 'application', 'application', 'layouts/', 1, 'haml', 0, 0, '0000-00-00 00:00:00', '2015-05-13 23:11:20', 0, 1, NULL),
(125, 'Text pages', NULL, 'textpages', 'textpages', '', NULL, NULL, NULL, 0, '2015-05-13 23:11:38', '2015-05-13 23:11:38', 1, 1, NULL),
(126, 'Home', NULL, 'home', 'home', '', NULL, NULL, NULL, 0, '2015-05-13 23:12:02', '2015-05-13 23:12:02', 1, 1, NULL),
(127, 'home', NULL, 'index', 'home/index', 'home/', 2, 'haml', NULL, 0, '2015-05-13 23:12:20', '2015-05-13 23:12:20', 0, 1, '126'),
(128, 'Sitemap', NULL, 'sitemap', 'textpages/sitemap', 'textpages/', 2, 'html', NULL, 0, '2015-05-13 23:26:11', '2015-05-13 23:26:11', 0, 1, '125'),
(129, 'test img', NULL, 'test_img', 'textpages/test_img', 'textpages/', 2, 'html', NULL, 0, '2015-05-17 14:19:13', '2015-05-17 14:19:13', 0, 1, '125'),
(130, 'install_ubuntu', NULL, 'install_ubuntu', 'textpages/install_ubuntu', 'textpages/', 2, 'haml', NULL, 0, '2016-02-11 11:12:08', '2016-02-11 11:12:08', 0, 1, '125'),
(133, 'install_centos', NULL, 'install_centos', 'textpages/install_centos', 'textpages/', 2, 'haml', NULL, 0, '2016-02-11 11:22:31', '2016-02-11 11:22:31', 0, 1, '125'),
(134, 'install_mac', NULL, 'install_mac', 'textpages/install_mac', 'textpages/', 2, 'haml', NULL, 0, '2016-02-11 20:53:48', '2016-02-11 20:53:48', 0, 1, '125'),
(135, 'beta', NULL, 'beta', 'home/beta', 'home/', 2, 'haml', NULL, 0, '2016-02-12 11:42:52', '2016-02-12 11:42:52', 0, 1, '126'),
(138, 'download_me', NULL, 'download_me', 'home/download_me', 'home/', 2, 'haml', NULL, 0, '2016-02-15 15:30:37', '2016-02-15 15:30:37', 0, 1, '126'),
(139, 'debug', NULL, 'debug', 'debug', '', NULL, NULL, NULL, 0, '2016-02-19 10:41:36', '2016-02-19 10:41:36', 1, 1, NULL),
(140, 'index_users', NULL, 'index_users', 'debug/index_users', 'debug/', 2, 'haml', NULL, 0, '2016-02-19 10:41:51', '2016-02-19 10:41:51', 0, 1, '139'),
(141, 'Install Windows', NULL, 'install_windows', 'textpages/install_windows', 'textpages/', 2, 'haml', NULL, 0, '2016-02-22 13:29:34', '2016-02-22 13:29:34', 0, 1, '125'),
(142, 'Tour', NULL, 'tour', 'home/tour', 'home/', 3, 'haml', NULL, 0, '2016-02-23 10:20:45', '2016-02-23 10:20:45', 0, 1, '126');

-- --------------------------------------------------------

--
-- Table structure for table `cms_templates_translation`
--

CREATE TABLE IF NOT EXISTS `cms_templates_translation` (
  `id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `lang` varchar(5) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cms_templatetypes`
--

CREATE TABLE IF NOT EXISTS `cms_templatetypes` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pos` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cms_templatetypes`
--

INSERT INTO `cms_templatetypes` (`id`, `name`, `title`, `pos`) VALUES
(1, 'layout', 'Layout', 1),
(2, 'page', 'Page', 2),
(3, 'partial', 'Partial', 3),
(4, 'block', 'Block Views', 4);

-- --------------------------------------------------------

--
-- Table structure for table `cms_users`
--

CREATE TABLE IF NOT EXISTS `cms_users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cms_users`
--

INSERT INTO `cms_users` (`id`, `email`, `encrypted_password`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `sign_in_count`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`, `created_at`, `updated_at`) VALUES
(4, 'admin@example.com', '$2a$10$WVfuuuzUvBRGdLJSdI7mVe09fLoTG4XqWvSE8yE3ZZFbexv7Rz/zG', NULL, NULL, NULL, 321, '2016-09-20 14:03:28', '2016-09-20 08:30:06', '10.1.0.12', '127.0.0.1', '2015-11-23 13:45:14', '2016-09-20 14:03:28');

-- --------------------------------------------------------

--
-- Table structure for table `errors`
--

CREATE TABLE IF NOT EXISTS `errors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `errors`
--

INSERT INTO `errors` (`id`, `name`, `title`, `category`, `description`) VALUES
(1, 'general', 'Error', NULL, 'Unexpected error occurred'),
(2, 'cluster_create_general', 'Cannot create cluster', NULL, ''),
(3, 'auth_bad_username_or_password', 'Bad username or password', NULL, NULL),
(4, 'user_create_email_used', 'Email is already used', NULL, NULL),
(5, 'forbidden', 'Operation forbidden', NULL, NULL),
(6, 'token_invalid', 'Token invalid', NULL, NULL),
(7, 'token_notfound', 'Token not found', NULL, NULL),
(8, 'token_used', 'Token is already used', NULL, NULL),
(9, 'token_expired', 'Token has expired', NULL, NULL),
(10, 'auth_not_verified', 'Email not verified', 'auth', NULL),
(11, 'user_create_team_name_used', 'Team name is already used', NULL, NULL),
(12, 'user_create_username_used', 'Username is already used', NULL, NULL),
(13, 'user_create_error', 'Error creating user', NULL, NULL),
(15, 'option_not_found', 'Option not found', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `title`, `enabled`) VALUES
(1, 'superadmin', 'Super Admin', 1),
(2, 'admin', 'Admin', 1),
(3, 'user', 'User', 1);

-- --------------------------------------------------------

--
-- Table structure for table `instances`
--

CREATE TABLE IF NOT EXISTS `instances` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admin_notes` text COLLATE utf8_unicode_ci,
  `sysinfo` text COLLATE utf8_unicode_ci,
  `data` text COLLATE utf8_unicode_ci,
  `last_node_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invitations`
--

CREATE TABLE IF NOT EXISTS `invitations` (
  `id` int(11) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `from_user_id` int(11) DEFAULT NULL,
  `team_id` int(11) DEFAULT NULL,
  `cluster_id` int(11) DEFAULT NULL,
  `to_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `invitation_type` int(11) NOT NULL DEFAULT '0',
  `activated_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `library_applications`
--

CREATE TABLE IF NOT EXISTS `library_applications` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `git_repo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture_file_size` int(11) DEFAULT NULL,
  `picture_updated_at` datetime DEFAULT NULL,
  `category_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0',
  `color` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `library_applications`
--

INSERT INTO `library_applications` (`id`, `name`, `title`, `git_repo`, `description`, `picture_file_name`, `picture_content_type`, `picture_file_size`, `picture_updated_at`, `category_title`, `company_name`, `enabled`, `pos`, `color`) VALUES
(1, 'hadoop_plain', 'Hadoop plain', 'https://github.com/dfgrhfjegi', 'Base img desc for hadoop_plain', 'aid_renew_small.jpg', 'image/jpeg', 34555, '2016-09-08 08:53:03', 'Big Data', '0', 0, 100, '#00796B'),
(2, 'nginx', 'Nginx', 'https://github.com/dfgrhfjegi', 'Base img desc for nginx', 'nginx_logo.png', 'image/png', 86406, '2016-09-08 10:45:13', 'Web servers', '0', 0, 100, NULL),
(3, 'mysql', 'Mysql', 'https://github.com/dfgrhfjegi', 'Base img desc for mysql', 'mysql_logo.png', 'image/png', 19171, '2016-09-08 10:45:48', 'Databases', '0', 0, 100, NULL),
(4, 'datameer', 'Datameer', 'https://github.com/dfgrhfjegi', 'Base img desc for datameer', 'datameer_logo.jpg', 'image/jpeg', 15080, '2016-09-08 10:46:06', 'Big Data Analytics', '0', 1, 100, NULL),
(5, 'hadoop_cdh', 'Hadoop cloudera', '', '', 'aid_renew_small.jpg', 'image/jpeg', 34555, '2016-09-09 11:20:14', 'Big Data', '0', 0, 100, '#7C4DFF'),
(6, 'hadoop_hdp', 'Hadoop HDP', '', '', 'cloudera_logo.png', 'image/png', 8669, '2016-09-05 13:01:54', 'Big Data', '0', 0, 100, NULL),
(7, 'hadoop_mapr', 'Hadoop Mapr', '', '', 'IMG_0133.JPG', 'image/jpeg', 2117458, '2016-09-09 10:08:45', 'Big Data', '0', 0, 100, NULL),
(8, 'rocana', 'Rocana', '', 'Rocana’s advanced analytics constantly analyzes your entire infrastructure to spot important changes in activity and performance levels.\r\n\r\n<br> Detailed information: https://www.rocana.com/rocana-ops/advanced-analytics-anomaly-detection', 'rocana_logo.jpg', 'image/jpeg', 8437, '2016-09-08 10:23:29', 'IT Ops Analytics', 'Rocana, Inc.', 1, 1, '#388E3C'),
(9, 'zoomdata', 'Zoomdata', 'no git repository yet', 'Zoomdata is the fastest visual analytics for big data. Unlock insights with big data visualization at the speed of thought.', 'zoomdata.png', 'image/png', 60206, '2016-09-08 10:45:31', ' Big Data Analytics', 'Zoomdata', 1, 100, '#673AB7'),
(10, 'arcadia_data', 'Arcadia Data', 'no git repository', 'Arcadia Data unifies data discovery, visual analytics and business intelligence in a single, integrated platform that runs natively on your Hadoop clusters. No additional hardware required.', 'arc.png', 'image/png', 11424, '2016-09-15 15:39:38', 'Visual Analytics and BI', 'Arcadia Data Inc.', 1, 2, '#616161'),
(11, 'platfora', 'Platfora', 'no git repository', 'Platfora''s Big Data Discovery and Analytics platform is the only end-to-end solution native on Hadoop + Spark.', 'platf.png', 'image/png', 6724, '2016-09-15 15:40:04', 'Big Data Analytics', 'Platfora, Inc.', 1, 100, '#64FFDA'),
(12, 'yeti_data', 'Yeti Data', 'no git repository', 'Yeti Data''s analytic apps, powered by our Yeti Snowflake technology help you understand how effective each customer touch is with our data-driven approach.', 'yeti.png', 'image/png', 19007, '2016-09-15 15:40:22', 'Retail Analytics', '', 1, 100, '#0288D1');

-- --------------------------------------------------------

--
-- Table structure for table `library_services`
--

CREATE TABLE IF NOT EXISTS `library_services` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `pos` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `library_services`
--

INSERT INTO `library_services` (`id`, `name`, `title`, `description`, `enabled`, `pos`) VALUES
(1, 'nginx', 'title', NULL, 1, 0),
(5, 'hdfs', 'HDFS', NULL, 1, 0),
(6, 'ssh', 'SSH', NULL, 1, 0),
(7, 'hadoop_resource_manager', 'HDFS resource manager', NULL, 1, 0),
(8, 'hdfs_namenode_webui', 'HDFS name node web UI', NULL, 1, 0),
(9, 'hue', 'Hue', NULL, 1, 0),
(10, 'spark_master_webui', 'Spark master web UI', NULL, 1, 0),
(11, 'spark_history', 'Spark history', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) NOT NULL,
  `dialog_id` int(11) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `message` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `message_dialogs`
--

CREATE TABLE IF NOT EXISTS `message_dialogs` (
  `id` bigint(20) NOT NULL,
  `from_user_id` int(11) NOT NULL,
  `to_user_id` int(11) NOT NULL,
  `last_message_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `nodes`
--

CREATE TABLE IF NOT EXISTS `nodes` (
  `id` bigint(20) NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cluster_id` int(11) NOT NULL,
  `node_number` int(11) NOT NULL DEFAULT '0',
  `host_type_id` int(11) NOT NULL DEFAULT '1',
  `instance_id` int(11) DEFAULT NULL,
  `is_master` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `port` int(11) NOT NULL DEFAULT '0',
  `agent_port` int(11) DEFAULT NULL,
  `agent_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `system_info` text COLLATE utf8_unicode_ci NOT NULL,
  `status_changed` bigint(20) DEFAULT NULL,
  `options` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `env_settings` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `node_host_types`
--

CREATE TABLE IF NOT EXISTS `node_host_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `node_host_types`
--

INSERT INTO `node_host_types` (`id`, `name`, `title`, `enabled`) VALUES
(1, 'dedicated', 'Dedicated server', 1),
(2, 'virtualbox', 'VirtualBox', 1);

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `option_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `is_changed` tinyint(1) NOT NULL DEFAULT '1',
  `category` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `name`, `title`, `option_type`, `description`, `is_changed`, `category`, `value`) VALUES
(1, 'vagrant_url_windows', '', '', '', 1, NULL, 'http://51.0.1.6/inst/vagrant_1.7.4.msi'),
(2, 'gex_storage_url', 'Storage base url', 'string', '', 1, NULL, 'http://drive.google.com/gex/'),
(5, 'client_box_download_urls', 'client_box_download_urls', 'json', '', 1, NULL, '["http://51.0.1.6/boxes"]'),
(6, 'virtualbox_url_windows', '', '', '', 1, NULL, 'http://51.0.1.6/inst/VirtualBox-5.0.26-108824-Win.exe'),
(7, 'client_application_download_urls', '', 'json', '', 1, NULL, '["http://51.0.1.6/applications"]'),
(8, 'virtualbox_url_mac', '', '', '', 1, NULL, 'http://51.0.1.6/inst/VirtualBox-5.0.26-108824-OSX.dmg'),
(9, 'vagrant_url_mac', '', '', '', 1, NULL, 'http://51.0.1.6/inst/vagrant_1.7.4.dmg'),
(10, 'registration_countries', 'registration_countries', '', '', 1, NULL, '["UA", "US"]');

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `command_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `v` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `packages`
--

INSERT INTO `packages` (`id`, `name`, `command_name`, `v`, `status`) VALUES
(1, 'hadoop_spark', 'hadoop_spark', '', 1),
(3, 'swarm', 'swarm', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `schema_migrations`
--

CREATE TABLE IF NOT EXISTS `schema_migrations` (
  `version` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `schema_migrations`
--

INSERT INTO `schema_migrations` (`version`) VALUES
('20151201185620'),
('20160105172934'),
('20160111100915'),
('20160128162344'),
('20160128162836'),
('20160321142634'),
('20160321145938'),
('20160407122907'),
('20160407132004'),
('20160408094131'),
('20160408094413'),
('20160408100951'),
('20160408102216'),
('20160408125017'),
('20160412071837'),
('20160412123132'),
('20160412125426'),
('20160412152451'),
('20160412160216'),
('20160618121910'),
('20160620081840'),
('20160621104008'),
('20160621104855'),
('20160708150512'),
('20160728141325'),
('20160815094550'),
('20160909084823'),
('20160916120126'),
('20161129173135'),
('20161201112354'),
('20161201142957');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL,
  `cluster_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `ssh_port` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE IF NOT EXISTS `teams` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `uid` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `about` text COLLATE utf8_unicode_ci,
  `primary_admin_user_id` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `avatar_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_file_size` int(11) DEFAULT NULL,
  `avatar_updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `teams`
--

INSERT INTO `teams` (`id`, `name`, `uid`, `status`, `about`, `primary_admin_user_id`, `created_at`, `updated_at`, `avatar_file_name`, `avatar_content_type`, `avatar_file_size`, `avatar_updated_at`) VALUES
(1, 'galacticexchange', '3153487328287', 1, '2222bbb', 129, '2015-12-14 15:04:41', '2016-02-19 17:54:42', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `encrypted_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `status` tinyint(4) NOT NULL DEFAULT '0',
  `team_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `about` text COLLATE utf8_unicode_ci,
  `admin_notes` text COLLATE utf8_unicode_ci,
  `reset_password_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reset_password_sent_at` datetime DEFAULT NULL,
  `remember_created_at` datetime DEFAULT NULL,
  `sign_in_count` int(11) NOT NULL DEFAULT '0',
  `current_sign_in_at` datetime DEFAULT NULL,
  `last_sign_in_at` datetime DEFAULT NULL,
  `current_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_sign_in_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmation_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `confirmation_sent_at` datetime DEFAULT NULL,
  `failed_attempts` int(11) NOT NULL DEFAULT '0',
  `unlock_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sms_was_sent` datetime DEFAULT NULL,
  `locked_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `invitation_id` int(11) DEFAULT NULL,
  `avatar_file_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_content_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `avatar_file_size` int(11) DEFAULT NULL,
  `avatar_updated_at` datetime DEFAULT NULL,
  `registration_options` text COLLATE utf8_unicode_ci,
  `phone_number` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `registration_ip` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=475 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `encrypted_password`, `status`, `team_id`, `group_id`, `firstname`, `lastname`, `about`, `admin_notes`, `reset_password_token`, `reset_password_sent_at`, `remember_created_at`, `sign_in_count`, `current_sign_in_at`, `last_sign_in_at`, `current_sign_in_ip`, `last_sign_in_ip`, `confirmation_token`, `confirmed_at`, `confirmation_sent_at`, `failed_attempts`, `unlock_token`, `sms_was_sent`, `locked_at`, `created_at`, `updated_at`, `invitation_id`, `avatar_file_name`, `avatar_content_type`, `avatar_file_size`, `avatar_updated_at`, `registration_options`, `phone_number`, `registration_ip`, `country`) VALUES
(129, 'support', 'support@galacticexchange.io', '$2a$10$TcAGz9Sm7Lu5Ghb74eyvpeBm6jSRVwVH7Y4g0GF/2HYb9hMqWH6qW', 1, 1, 1, 'GEX', 'support', NULL, '', '26f4d611cb991fd8d2b53ef2137c619fa31fc25e20fa33bc7e056b2ce51c9e7a', '2016-02-19 14:50:38', NULL, 0, NULL, NULL, NULL, NULL, '', '2015-12-14 15:04:41', NULL, 0, NULL, NULL, NULL, '2015-12-14 15:04:41', '2016-02-19 14:57:11', NULL, 'shaun-tshirt-450x462.jpg', 'image/jpeg', 50059, '2016-02-19 14:57:10', NULL, NULL, NULL, NULL),
(443, 'system', 'system@galacticexchange.io', '$2a$10$FvOZ5iWZSQeDz91J6U8wTet.7qc47zcQQ7o00l/HgA8CCMAffomUi', 1, 1, 3, 'GEX', 'support', NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, '', '2016-05-19 12:49:09', NULL, 0, NULL, NULL, NULL, '2016-05-19 12:49:09', '2016-05-19 12:49:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application_images`
--
ALTER TABLE `application_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aws_instance_types`
--
ALTER TABLE `aws_instance_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `aws_regions`
--
ALTER TABLE `aws_regions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clusters`
--
ALTER TABLE `clusters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `systemname` (`domainname`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `uid` (`uid`),
  ADD KEY `primary_admin_id` (`primary_admin_user_id`),
  ADD KEY `team_id` (`team_id`);

--
-- Indexes for table `cluster_access`
--
ALTER TABLE `cluster_access`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `cluster_applications`
--
ALTER TABLE `cluster_applications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `library_application_id` (`library_application_id`);

--
-- Indexes for table `cluster_containers`
--
ALTER TABLE `cluster_containers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `container_id` (`application_id`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `node_id` (`node_id`),
  ADD KEY `ip` (`status`),
  ADD KEY `host` (`public_ip`),
  ADD KEY `application_id` (`application_id`);

--
-- Indexes for table `cluster_hadoop_types`
--
ALTER TABLE `cluster_hadoop_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `cluster_services`
--
ALTER TABLE `cluster_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `application_id` (`application_id`);

--
-- Indexes for table `cluster_service_endpoints`
--
ALTER TABLE `cluster_service_endpoints`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `node_id` (`node_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `container_id` (`container_id`);

--
-- Indexes for table `cluster_types`
--
ALTER TABLE `cluster_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `cms_languages`
--
ALTER TABLE `cms_languages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idxLang` (`lang`);

--
-- Indexes for table `cms_mediafiles`
--
ALTER TABLE `cms_mediafiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_pages`
--
ALTER TABLE `cms_pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `parent_id` (`parent_id`),
  ADD KEY `status` (`status`),
  ADD KEY `url` (`url`),
  ADD KEY `index_cms_pages_on_name` (`name`);

--
-- Indexes for table `cms_pages_translation`
--
ALTER TABLE `cms_pages_translation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `template` (`template_filename`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `lang` (`lang`);

--
-- Indexes for table `cms_templates`
--
ALTER TABLE `cms_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ancestry` (`ancestry`),
  ADD KEY `basepath` (`basepath`),
  ADD KEY `pos` (`pos`);

--
-- Indexes for table `cms_templates_translation`
--
ALTER TABLE `cms_templates_translation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_id` (`item_id`,`lang`);

--
-- Indexes for table `cms_templatetypes`
--
ALTER TABLE `cms_templatetypes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cms_users`
--
ALTER TABLE `cms_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `index_optimacms_cms_users_on_email` (`email`),
  ADD UNIQUE KEY `index_optimacms_cms_users_on_reset_password_token` (`reset_password_token`);

--
-- Indexes for table `errors`
--
ALTER TABLE `errors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `instances`
--
ALTER TABLE `instances`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`);

--
-- Indexes for table `invitations`
--
ALTER TABLE `invitations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD KEY `user_id` (`from_user_id`),
  ADD KEY `cluster_id` (`team_id`);

--
-- Indexes for table `library_applications`
--
ALTER TABLE `library_applications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `library_services`
--
ALTER TABLE `library_services`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_user_id` (`from_user_id`,`to_user_id`);

--
-- Indexes for table `message_dialogs`
--
ALTER TABLE `message_dialogs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `from_user_id` (`from_user_id`),
  ADD KEY `to_user_id` (`to_user_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `updated_at` (`updated_at`);

--
-- Indexes for table `nodes`
--
ALTER TABLE `nodes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `uid` (`uid`),
  ADD KEY `name` (`name`),
  ADD KEY `cluster_id` (`cluster_id`),
  ADD KEY `agent_token` (`agent_token`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `node_host_types`
--
ALTER TABLE `node_host_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `index_options_on_name` (`name`);

--
-- Indexes for table `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `name` (`name`);

--
-- Indexes for table `schema_migrations`
--
ALTER TABLE `schema_migrations`
  ADD UNIQUE KEY `unique_schema_migrations` (`version`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `uid` (`uid`),
  ADD UNIQUE KEY `uid_2` (`uid`),
  ADD KEY `primary_admin_user_id` (`primary_admin_user_id`),
  ADD KEY `created_at` (`created_at`),
  ADD KEY `updated_at` (`updated_at`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `index_users_on_reset_password_token` (`reset_password_token`),
  ADD KEY `team_id` (`team_id`),
  ADD KEY `group_id` (`group_id`),
  ADD KEY `email` (`email`),
  ADD KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application_images`
--
ALTER TABLE `application_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `aws_instance_types`
--
ALTER TABLE `aws_instance_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=139;
--
-- AUTO_INCREMENT for table `aws_regions`
--
ALTER TABLE `aws_regions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=85;
--
-- AUTO_INCREMENT for table `clusters`
--
ALTER TABLE `clusters`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_access`
--
ALTER TABLE `cluster_access`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_applications`
--
ALTER TABLE `cluster_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_containers`
--
ALTER TABLE `cluster_containers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_hadoop_types`
--
ALTER TABLE `cluster_hadoop_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cluster_services`
--
ALTER TABLE `cluster_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_service_endpoints`
--
ALTER TABLE `cluster_service_endpoints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cluster_types`
--
ALTER TABLE `cluster_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cms_languages`
--
ALTER TABLE `cms_languages`
  MODIFY `id` int(3) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cms_mediafiles`
--
ALTER TABLE `cms_mediafiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `cms_pages`
--
ALTER TABLE `cms_pages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=162;
--
-- AUTO_INCREMENT for table `cms_pages_translation`
--
ALTER TABLE `cms_pages_translation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=369;
--
-- AUTO_INCREMENT for table `cms_templates`
--
ALTER TABLE `cms_templates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=143;
--
-- AUTO_INCREMENT for table `cms_templates_translation`
--
ALTER TABLE `cms_templates_translation`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `cms_templatetypes`
--
ALTER TABLE `cms_templatetypes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cms_users`
--
ALTER TABLE `cms_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `errors`
--
ALTER TABLE `errors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `instances`
--
ALTER TABLE `instances`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `invitations`
--
ALTER TABLE `invitations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `library_applications`
--
ALTER TABLE `library_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `library_services`
--
ALTER TABLE `library_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `message_dialogs`
--
ALTER TABLE `message_dialogs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `nodes`
--
ALTER TABLE `nodes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `node_host_types`
--
ALTER TABLE `node_host_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=33;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=475;

